import {env} from 'cloudflare:workers';
export function GET(){return Response.json({service:'Medora Learning Studio',version:'0.2',aiConfigured:!!(env.OPENAI_API_KEY||process.env.OPENAI_API_KEY),storageConfigured:!!env.DB&&!!env.BUCKET},{headers:{'Cache-Control':'no-store'}})}
