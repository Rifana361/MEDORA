import {AppError,db,sameOrigin,json,failure,guestIdentity,tokenHash,GUEST_COOKIE} from '../../../lib/server-learning';
export async function POST(req:Request){try{
 sameOrigin(req);
 if(req.headers.get('sec-fetch-site')==='cross-site')throw new AppError(403,'Open MEDORA directly to start a guest workspace.');
 if(req.headers.get('oai-authenticated-user-id'))return json({mode:'account',expires:null});
 const existing=await guestIdentity(req);if(existing)return json({mode:'guest',expires:existing.expires});
 // Bound new sessions as well as AI requests; rotating cookies must not bypass the shared budget.
 const now=Date.now(),ip=req.headers.get('cf-connecting-ip'),scope=ip?'guest-session:'+await tokenHash(ip):'guest-session:unknown';
 const total=await db().prepare("SELECT COUNT(*) AS n FROM usage WHERE owner LIKE 'guest-session:%' AND created>?").bind(now-3600000).first<{n:number}>();
 const local=await db().prepare('SELECT COUNT(*) AS n FROM usage WHERE owner=? AND created>?').bind(scope,now-3600000).first<{n:number}>();
 if((total?.n||0)>=100||(ip&&(local?.n||0)>=10))throw new AppError(429,'Too many new guest sessions. Keep your existing browser cookies and try again later.','SESSION_LIMIT');
 const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
 const owner='guest:'+crypto.randomUUID(),expires=now+30*86400000;
 await db().batch([db().prepare('INSERT INTO guest_sessions(token_hash,owner,created,expires) VALUES(?,?,?,?)').bind(await tokenHash(token),owner,now,expires),db().prepare('INSERT INTO usage(id,owner,created) VALUES(?,?,?)').bind(crypto.randomUUID(),scope,now)]);
 const response=json({mode:'guest',expires});
 response.headers.set('Set-Cookie',`${GUEST_COOKIE}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${new URL(req.url).protocol==='https:'?'; Secure':''}`);
 return response;
}catch(e){return failure(e)}}
