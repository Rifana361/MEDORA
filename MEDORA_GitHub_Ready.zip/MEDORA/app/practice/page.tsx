import {redirect} from 'next/navigation';
export default function RetiredStarterCollection(){redirect('/')}
