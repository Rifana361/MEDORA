import type {Kit} from './learning-types';
const esc=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
export function lines(s:string,chars:number,max=8){const words=s.replace(/\s+/g,' ').split(' '),out:string[]=[];let row='';for(const w of words){if(row.length+w.length+1>chars&&row){out.push(row);row=w}else row+=(row?' ':'')+w}if(row)out.push(row);return out.slice(0,max).map((x,i)=>i===max-1&&out.length>max?x+'…':x)}
const text=(s:string,x:number,y:number,width=40,size=17,color='#244d43',max=8)=>`<text x="${x}" y="${y}" font-family="Arial, sans-serif" font-size="${size}" fill="${color}">${lines(s,width,max).map((l,i)=>`<tspan x="${x}" dy="${i?size*1.5:0}">${esc(l)}</tspan>`).join('')}</text>`;
export {compactInfographicSvg as infographicSvg} from './study-graphics';
export function saveDownload(content:BlobPart,name:string,type:string){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),3000)}
