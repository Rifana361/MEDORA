import {bucket} from './server-learning';
import type {NotebookData} from './learning-types';
import type {SourceIndex,SourceSegment,SourceDocument} from './study-types';
const MAX_CHARS=180000;
export async function buildSourceIndex(data:NotebookData):Promise<SourceIndex>{
 const segments:SourceSegment[]=[],documents:SourceDocument[]=[];let used=0;
 const add=(file:string,text:string,location:string,page?:number)=>{let rest=text.trim();let part=1;while(rest&&used<MAX_CHARS){const take=Math.min(2400,MAX_CHARS-used),chunk=rest.slice(0,take);segments.push({id:'s'+segments.length,file,location:location+(rest.length>2400?' · chunk '+part:''),...(page?{page}:{}),text:chunk});used+=chunk.length;if(rest.length<=take){rest='';break}rest=rest.slice(Math.max(1,take-120));part++}return !rest||rest.length<120};
 if(data.text){const paragraphs=data.text.split(/\n\s*\n/).filter(Boolean);paragraphs.forEach((p,i)=>add('Pasted notes',p,'Pasted notes · paragraph '+(i+1)));documents.push({file:'Pasted notes',kind:'pasted',status:used>=MAX_CHARS?'partial':'indexed',reason:'Paragraph locations refer to your saved pasted notes.'})}
 for(const file of data.files){const kind=file.type==='application/pdf'?'pdf':/text\/|csv/.test(file.type)?'text':'other';const doc:SourceDocument={file:file.name,kind,status:'unavailable',reason:''};documents.push(doc);
  if(file.uploaded===false){doc.reason='Upload incomplete.';continue}
  if(used>=MAX_CHARS){doc.reason='The notebook text-index limit was reached.';continue}
  if(kind==='other'){doc.reason='Exact text indexing is currently available for text PDFs, TXT, Markdown and CSV. The AI can still read other supported formats, but their locations are unverified.';continue}
  if(file.size>8_000_000){doc.reason='Text indexing is limited to files up to 8 MB. This does not change upload or AI analysis limits.';continue}
  try{const object=await bucket().get(file.key);if(!object)throw Error('Missing original');const bytes=await object.arrayBuffer();
   if(kind==='text'){add(file.name,new TextDecoder().decode(bytes),'Saved text');doc.status=used>=MAX_CHARS?'partial':'indexed';doc.reason='Text matched against the saved original; no page numbering is assumed.';continue}
   const {getDocumentProxy}=await import('unpdf');const pdf=await getDocumentProxy(new Uint8Array(bytes),{maxImageSize:0,useSystemFonts:false,disableFontFace:true});
   doc.totalPages=pdf.numPages;doc.indexedPages=0;let missing=0;
   try{for(let page=1;page<=Math.min(pdf.numPages,80)&&used<MAX_CHARS;page++){const p=await pdf.getPage(page);const content=await p.getTextContent();const text=content.items.map((item:any)=>item.str||'').join(' ');if(text.trim().length<20)missing++;else add(file.name,text,'PDF page '+page,page);doc.indexedPages++;p.cleanup()}}finally{await pdf.loadingTask.destroy()}
   doc.status=doc.indexedPages===doc.totalPages&&used<MAX_CHARS&&!missing?'indexed':'partial';doc.reason=`${doc.indexedPages} of ${doc.totalPages} PDF pages inspected for text. ${missing?missing+' inspected page(s) had little or no readable text. ':''}Locations use PDF page order, not printed page numbers. Figures and text meaning are not verified.`;
  }catch{doc.reason='Text could not be extracted safely. This may be a scan, protected PDF, unsupported font or unreadable file. Use the original; no location verification is claimed.'}
 }
 return {version:1,created:Date.now(),documents,segments};
}
