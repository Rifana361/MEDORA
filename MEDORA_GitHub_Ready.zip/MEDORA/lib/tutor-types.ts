import type {Evidence} from './learning-types';
export const sectionKeys=['meaning','foundations','mechanism','example','contrast','limits'] as const;
export type SectionKey=typeof sectionKeys[number];
export type TeachingBasis='source'|'teaching'|'not_established';
export type TutorSection={key:SectionKey;title:string;points:string[];basis:TeachingBasis;evidence:Evidence[]};
export type TutorCard={kind:'idea'|'mechanism'|'example'|'trap'|'analogy';question:string;hint:string;answer:string;why:string;trap:string;evidence:Evidence[]};
export type TutorLesson={version:1;title:string;sections:TutorSection[];terms:{term:string;meaning:string}[];visual:{kind:'concept'|'process'|'compare';nodes:{label:string;detail:string}[];caption:string};analogy:{comparison:string;limit:string};cards:TutorCard[];coverage:{included:string[];notEstablished:string[];nextQuestions:string[]}};
export type TutorPack={version:1;conceptId:string;inputKey:string;created:number;level:string;context:boolean;difficulty:string;lesson:TutorLesson};
