import type {TeachingDeck} from './learning-types';
export const recallTeaching:TeachingDeck={
  "version": 2,
  "title": "Retrieve before you reread",
  "goal": "Use retrieval practice to find and correct gaps in your understanding.",
  "slides": [
    {
      "title": "What is retrieval practice?",
      "kind": "concept",
      "nodes": [
        {
          "label": "Produce an answer",
          "detail": "Explain what you remember before seeing the source again.",
          "icon": "brain"
        },
        {
          "label": "Notice gaps",
          "detail": "Identify what you can explain and what needs work.",
          "icon": "target"
        }
      ],
      "bullets": [],
      "takeaway": "Retrieval makes gaps in your explanation visible.",
      "notes": "The useful outcome is not simply a score."
    },
    {
      "title": "Try it step by step",
      "kind": "process",
      "nodes": [
        {
          "label": "Read a section",
          "detail": "Begin with a small section.",
          "icon": "book"
        },
        {
          "label": "Close and explain",
          "detail": "Close the source and write a short explanation.",
          "icon": "brain"
        },
        {
          "label": "Check and correct",
          "detail": "Return to the relevant passage and correct gaps.",
          "icon": "check"
        }
      ],
      "bullets": [],
      "takeaway": "Explain first, then use the source to check your answer.",
      "notes": "If you cannot recall an idea, return to the relevant passage."
    },
    {
      "title": "Example: recall a process",
      "kind": "example",
      "nodes": [
        {
          "label": "Close the page",
          "detail": "After reading about a process, put the source aside.",
          "icon": "book"
        },
        {
          "label": "Describe three stages",
          "detail": "Write the main stages from memory, then check them.",
          "icon": "path"
        }
      ],
      "bullets": [],
      "takeaway": "A short explanation is enough to reveal what needs checking.",
      "notes": "This is a hypothetical example."
    },
    {
      "title": "Familiarity is not recall",
      "kind": "compare",
      "nodes": [
        {
          "label": "Recognition with clues",
          "detail": "A familiar-looking page supplies clues.",
          "icon": "book"
        },
        {
          "label": "Recall without clues",
          "detail": "You produce an explanation without the source.",
          "icon": "brain"
        }
      ],
      "bullets": [],
      "takeaway": "A familiar page does not prove you can explain it.",
      "notes": "Check your explanation against the source after attempting recall."
    }
  ],
  "memoryCue": "Close, explain, check.",
  "checkQuestion": "After reading a small section, what should you do before rereading it?",
  "sourceNote": "Prepared example based on the saved learning notes. These are teaching diagrams, not original research figures."
};
