// Decimal MB keeps the raw request inside the hosting provider's 100 MB cap.
export const MAX_FILE_BYTES=100_000_000;
export const MAX_NOTEBOOK_BYTES=100_000_000;
export const MAX_FILES=3;
export const sourceMime:Record<string,string>={pdf:'application/pdf',txt:'text/plain',md:'text/markdown',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation',csv:'text/csv',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp'};
export function validateUploads(files:{name:string;size:number}[]){
 if(files.length>MAX_FILES)throw new Error('Add up to 3 files per notebook.');
 if(files.some(f=>!Number.isSafeInteger(f.size)||f.size<=0||f.size>MAX_FILE_BYTES))throw new Error('Each file must be nonempty and no larger than 100 MB.');
 if(files.reduce((sum,f)=>sum+f.size,0)>MAX_NOTEBOOK_BYTES)throw new Error('Keep the combined upload at or below 100 MB per notebook.');
 if(files.some(f=>typeof f.name!=='string'||!sourceMime[f.name.split('.').pop()?.toLowerCase()||'']))throw new Error('Supported files: PDF, DOCX, PPTX, TXT, Markdown, CSV, XLSX, PNG, JPG and WebP.');
}
