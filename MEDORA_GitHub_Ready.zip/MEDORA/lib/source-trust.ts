import type {Evidence} from './learning-types';
import type {SourceIndex,EvidenceMatch} from './study-types';
export const normaliseSource=(s:string)=>s.normalize('NFKC').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/\s+/g,' ').trim().toLocaleLowerCase();
export function matchEvidence(e:Evidence,index?:SourceIndex):EvidenceMatch{
 if(!e.quote?.trim())return {status:'empty',note:'No source excerpt was supplied.'};
 const segments=index?.segments.filter(s=>s.file===e.file)||[];
 if(!segments.length)return {status:'not_indexed',note:'Original text has not been indexed for this source. Check the original file.'};
 const query=normaliseSource(e.quote);if(query.length<8)return {status:'not_found',note:'The excerpt is too short to verify reliably.'};
 const segment=segments.find(s=>normaliseSource(s.text).includes(query));
 if(!segment)return {status:'not_found',note:'This excerpt was not found in indexed text. It may be incorrect or outside indexed coverage.'};
 const normal=normaliseSource(segment.text),at=normal.indexOf(query),excerpt=segment.text.replace(/\s+/g,' ').slice(Math.max(0,at-110),at+query.length+180);
 return {status:'matched',segmentId:segment.id,location:segment.location,excerpt,note:'Text matched after normalising whitespace, typography and case. This checks the excerpt, not whether the explanation is medically correct.'};
}
