import type {TutorPack} from './tutor-types';
import type {Concept,Evidence} from './learning-types';
export type FlashcardKind='idea'|'mechanism'|'example'|'trap'|'analogy';
export type Flashcard={id:string;conceptId:string;concept:string;kind:FlashcardKind;label:string;question:string;hint?:string;answer:string;explanation:{label:string;text:string}[];evidence:Evidence[]};
export type RecallRating='again'|'almost'|'remembered';
function fingerprint(s:string){let hash=2166136261;for(let i=0;i<s.length;i++)hash=Math.imul(hash^s.charCodeAt(i),16777619);return (hash>>>0).toString(36)}
export function makeFlashcards(concepts:Concept[],packs:Record<string,TutorPack>={}):Flashcard[]{return concepts.flatMap(c=>{
 const pack=packs[c.id];if(pack?.lesson.cards.length)return pack.lesson.cards.map(d=>({id:c.id+':tutor:'+fingerprint(JSON.stringify(d)),conceptId:c.id,concept:c.title,kind:d.kind,label:{idea:'Explain it',mechanism:'Connect it',example:'Apply it',trap:'Distinguish it',analogy:'Memory bridge'}[d.kind],question:d.question,hint:d.hint,answer:d.answer,explanation:[{label:'Why this answer works',text:d.why},{label:'A tempting wrong turn',text:d.trap}],evidence:d.evidence}));
 const path=c.learningPath;
 const definitions:{kind:FlashcardKind;label:string;question:string;hint?:string;answer:string;explanation:{label:string;text:string}[]}[]=[
  {kind:'idea',label:'The core idea',question:`How would you explain “${c.title}” in your own words?`,answer:c.simple,explanation:[{label:'Understand why',text:c.detail}]},
  {kind:'mechanism',label:'How it works',question:`What happens, and why, in “${c.title}”?`,answer:path?.mechanism||c.detail,explanation:path?[{label:'Starting point',text:path.baseline},{label:'What you would notice',text:path.findings},{label:'What remains uncertain',text:path.uncertainty}]:[{label:'Connect it to the central idea',text:c.simple}]},
  {kind:'example',label:'Make it concrete',question:`Describe the saved lesson’s example of “${c.title}”.`,answer:c.example,explanation:[{label:'Connect the example',text:c.simple},...(path?[{label:'Look for these clues',text:path.distinction}]:[])]},
  {kind:'trap',label:'Spot the trap',question:`Which common mistake should you avoid with “${c.title}”?`,answer:c.commonMistake,explanation:[{label:'Keep this principle',text:c.simple},{label:'Why the distinction matters',text:c.detail}]},
  {kind:'analogy',label:'A memory bridge',question:`Which analogy does the lesson use to explain “${c.title}”?`,answer:c.analogy,explanation:[{label:'Return to the actual concept',text:c.simple},{label:'Use analogies carefully',text:'A memory aid is not evidence. Check the original source before applying the idea.'}]},
 ];
 return definitions.filter(d=>d.answer?.trim()).map(d=>({...d,id:c.id+':'+d.kind+':'+fingerprint(JSON.stringify(d)),conceptId:c.id,concept:c.title,evidence:c.evidence}));
})}
export function flashcardsCsv(cards:Flashcard[]){const cell=(s:string)=>'"'+(/^[\s]*[=+@-]/.test(s)?"'"+s:s).replace(/"/g,'""')+'"';return [['Front','Answer','Explanation','Category','Concept','Source references'],...cards.map(c=>[c.question,c.answer,c.explanation.map(e=>e.label+': '+e.text).join('\n\n'),c.label,c.concept,c.evidence.map(e=>e.file+' · '+e.location).join('; ')])].map(row=>row.map(cell).join(',')).join('\r\n')}
