import type {NotebookData} from './learning-types';
export function analysisSources(data:NotebookData,selection:unknown=data.analysisFiles):NotebookData{
 if(selection===undefined)return data;
 if(!Array.isArray(selection)||selection.some(i=>!Number.isInteger(i)||i<0||i>=data.files.length)||new Set(selection).size!==selection.length)throw Error('Choose valid source files for analysis.');
 if(!selection.length&&data.text.trim().length<40)throw Error('Select at least one file or paste at least 40 characters of educational notes.');
 return {...data,files:selection.map(i=>data.files[i]),analysisFiles:undefined};
}
export function analysisSizeError(files:{size:number;type:string}[]){return files.reduce((n,f)=>n+f.size,0)>=50_000_000?'Selected files must total less than 50 MB for AI analysis. Deselect a file to study a smaller batch, or paste a relevant excerpt with large files deselected.':files.some(f=>f.type.startsWith('image/')&&f.size>20_000_000)?'AI analysis supports images up to 20 MB. Deselect the larger image and add a smaller version or relevant text.':''}
