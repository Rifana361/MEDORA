import type {ReviewReason} from './study-types';
export const reviewReasons:ReviewReason[]=['Unsure','Foundation gap','Look-alike confusion','Missed clue','Reasoning gap','Confident misconception','Not attempted'];
export function nextReview(interval:number,outcome:string,now=Date.now()){
 if(outcome==='Again')return {interval:0,due:now+10*60000};
 if(outcome==='Needs practice')return {interval:1,due:now+86400000};
 const next=[1,3,7,14,30].find(days=>days>interval)||30;return {interval:next,due:now+next*86400000};
}
